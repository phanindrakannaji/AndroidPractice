package com.example.android.inclassassignment3;

/**
 * Created by phani on 4/27/17.
 */

public class User {

    public String email;
    public String fullName;
    public String password;

    public User(){

    }

    public User(String email, String fullName, String password) {
        this.email = email;
        this.fullName = fullName;
        this.password = password;
    }
}
